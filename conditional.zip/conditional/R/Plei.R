#conditional plei (call)



Plei=function(X,Y,pr=c(1:(nrow(YY0)),nrow(YY0)*nrow(XX)+1),method="wald",ay=1,suby=c()){
  n=nrow(X)
  q=ncol(X)
  p=ncol(Y)
  BM=SM=matrix(ncol=q,nrow=p)

  Xnull=t(t(X)-colMeans(X))
  Y0=t(t(Y)-colMeans(Y))

  xny=t(Xnull)%*%Y0 #X'Y
  xnx=colSums(Xnull^2) #X'X
  bbb=xny/xnx
  BM=t(bbb)
  for(i in 1:p){
    Yfit1=(t(Xnull)*bbb[,i])
    rs1=t(t(Yfit1)-Y0[,i])
    ss1=sqrt(rowSums(rs1^2)/(n-1))
    se1=ss1/sqrt(xnx)
    SM[i,]=se1
  }

  XX=cov(X)
  YY0=cor(Y)

  pr2=length(pr)-1
  tt1=c()
  if(method=="lrt"){
    if(ay==0){
      for(k in pr){
        tt1=c(tt1,pleiward3(BM,SM,XX,YY0,n,k))
      }
    }else{
      for(k in pr){
        tt1=c(tt1,pleiward2(BM,SM,XX,YY0,n,k))
      }
    }
  }
  if(method=="wald"){
    for(k in pr){
      tt1=c(tt1,pleiward_ols(BM,SM,XX,YY0,n,k,method=method,ay=ay,suby=suby))
    }
  }
  tt2=min(tt1[1:pr2])
  aaa=c(pchisq(tt1[pr2+1],df=pr2,lower.tail=FALSE),pchisq(tt2,df=pr2-1,lower.tail=FALSE))
  return(aaa)
}

#conditional plei (lrt sum)
pleiward2=function(BM,SM,XX=matrix(1,nrow=1,ncol=1),YY0,n,k,lam=0){
  p=nrow(YY0)
  q=nrow(XX)
  BM=as.matrix(BM)
  SM=as.matrix(SM)
  rx=1
  ny=ncol(YY0)
  xx=XX[rx,rx]
  S1=SM[,rx]
  B1=BM[,rx]
  YY2=(n-1)*xx*S1^2+xx*B1^2

  XY=matrix(nrow=q,ncol=p)
  for(i in 1:q){
    for(j in 1:p){
      XY[i,j]=XX[i,i]*BM[j,i]
    }
  }

  YYcross=matrix(nrow=p,ncol=p)
  for(i1 in 1:p){
    for(j1 in 1:p){
      if(i1==j1){
        YYcross[i1,j1]=YY2[i1]
      }
      else{
        YYcross[i1,j1]=YY0[i1,j1]*sqrt(YY2[i1]*YY2[j1])
      }
    }
  }

  XX1=matrix(nrow=p*q,ncol=p*q)
  for(i in 1:q){
    for(j in 1:q){
      XX1[c(1:p+(i-1)*p),c(1:p+(j-1)*p)]=diag(p)*XX[i,j]
    }
  }

  XY1=as.matrix(c(t(XY)))

  XyXy=kronecker(rbind(cbind(XX,XY),cbind(t(XY),YYcross)),diag(p))
  XyY=rbind(XY1,as.matrix(as.vector(YYcross)))
  G=diag(p*q+p^2)
  del=p*q+(0:(p-1))*(p+1)+1
  G=G[,-del]

  B0=solve(t(G)%*%XyXy%*%G)%*%t(G)%*%XyY

  la=solve(t(G)%*%XyXy%*%G)

  corB0=la%*%(t(G)%*%XyXy%*%G)%*%t(la)

  A=Sest22(XY,XX,YYcross,B0,n,p,q)   #get Sigma     RIGHT when XX=XXtrue
  As=solve(A)    #S-1
  AA=kronecker(XX,As)   #X'(S-1)X       ######CHANGED

  AA2=kronecker(rbind(cbind(XX,XY),cbind(t(XY),YYcross)),As)
  XwanX=t(G)%*%AA2%*%G




  V0=matrix(0,nrow=p,ncol=p*q+p*(p-1))
  V0[1:p,1:p]=diag(p)

  BB=matrix(nrow=p*q+p*p,ncol=1)
  for(l1 in 1:q){
    for(l2 in 1:p){
      BB[l2+(l1-1)*p]=t(As[l2,])%*%XY[l1,]
    }
  }
  for(l1 in 1:p){
    for(l2 in 1:p){
      BB[p*q+l2+(l1-1)*p]=t(As[l2,])%*%YYcross[l1,]
    }
  }
  XwanY=t(G)%*%BB

  Vk=as.matrix(V0[-k,])
  if(min(dim(Vk))==1){
    Vk=t(Vk)
  }
  AA2=solve(XwanX)

  AA2=(AA2+lam*diag(nrow(AA2)))/(1+lam)

  C=t(XwanY)%*%AA2%*%t(Vk)
  D=Vk%*%AA2%*%t(Vk)
  t=C%*%solve(D)%*%t(C)

  return(t)
}

#marginal plei (lrt sum)
pleiward3=function(BM,SM,XX=matrix(1,nrow=1,ncol=1),YY0,n,k){
  p=nrow(YY0)
  q=nrow(XX)
  BM=as.matrix(BM)
  SM=as.matrix(SM)
  rx=1
  ny=ncol(YY0)
  xx=XX[rx,rx]
  S1=SM[,rx]
  B1=BM[,rx]
  YY2=(n-1)*xx*S1^2+xx*B1^2

  XY=matrix(nrow=q,ncol=p)
  for(i in 1:q){
    for(j in 1:p){
      XY[i,j]=XX[i,i]*BM[j,i]
    }
  }

  YYcross=matrix(nrow=p,ncol=p)
  for(i1 in 1:p){
    for(j1 in 1:p){
      if(i1==j1){
        YYcross[i1,j1]=YY2[i1]
      }
      else{
        YYcross[i1,j1]=YY0[i1,j1]*sqrt(YY2[i1]*YY2[j1])
      }
    }
  }

  XX1=matrix(nrow=p*q,ncol=p*q)
  for(i in 1:q){
    for(j in 1:q){
      XX1[c(1:p+(i-1)*p),c(1:p+(j-1)*p)]=diag(p)*XX[i,j]
    }
  }

  XY1=as.matrix(c(t(XY)))

  B0=solve(XX1)%*%XY1    #OLS
  B=matrix(B0,nrow=p)

  A=Sest(XY,XX,YYcross,B,n,p,q)
  As=solve(A)
  AA=kronecker(As,XX)

  V0=matrix(0,nrow=p,ncol=p*q)     #may be wrong
  V0[1:p,1:p]=diag(p)

  BB=matrix(nrow=p*q,ncol=1)
  for(l1 in 1:q){
    for(l2 in 1:p){
      BB[l2+(l1-1)*p]=t(As[l2,])%*%XY[l1,]
    }
  }
  XY2=t(BB)

  Vk=as.matrix(V0[-k,])
  if(min(dim(Vk))==1){
    Vk=t(Vk)
  }
  SX=solve(XX1)
  AA2=solve(AA)
  C=XY2%*%AA2%*%t(Vk)
  D=Vk%*%AA2%*%t(Vk)
  t=C%*%solve(D)%*%t(C)

  Btrans=solve(AA)%*%t(XY2)  #GLS
  Bcort=solve(AA)

  return(t)
}

#marginal/conditional plei (wald ind)

#marginal/conditional plei (wald sum)
pleiward_ols=function(BM,SM,XX=matrix(1,nrow=1,ncol=1),YY0,n,k,lam=0,method="wald",ay,suby=c()){
  p=nrow(YY0)
  q=nrow(XX)
  BM=as.matrix(BM)
  SM=as.matrix(SM)
  rx=1
  ny=ncol(YY0)
  xx=XX[rx,rx]
  S1=SM[,rx]
  B1=BM[,rx]
  YY2=(n-1)*xx*S1^2+xx*B1^2

  XY=matrix(nrow=q,ncol=p)
  for(i in 1:q){
    for(j in 1:p){
      XY[i,j]=XX[i,i]*BM[j,i]
    }
  }

  YYcross=matrix(nrow=p,ncol=p)
  for(i1 in 1:p){
    for(j1 in 1:p){
      if(i1==j1){
        YYcross[i1,j1]=YY2[i1]
      }
      else{
        YYcross[i1,j1]=YY0[i1,j1]*sqrt(YY2[i1]*YY2[j1])
      }
    }
  }

  XX1=matrix(nrow=p*q,ncol=p*q)
  for(i in 1:q){
    for(j in 1:q){
      XX1[c(1:p+(i-1)*p),c(1:p+(j-1)*p)]=diag(p)*XX[i,j]
    }
  }

  XY1=as.matrix(c(t(XY)))

  XyXy=kronecker(rbind(cbind(XX,XY),cbind(t(XY),YYcross)),diag(p))
  XyY=rbind(XY1,as.matrix(as.vector(YYcross)))
  G=diag(p*q+p^2)
  del=c(p*q+(0:(p-1))*(p+1)+1)
  if(length(suby)>0){
    for(i in 1:length(suby)){
      del=c(del,p*q+(suby[i]-1)*p+1:p)
    }
  }
  G=G[,-del]

  if(ay==0){
    G=diag(p*q+p^2)
    G=G[,1:(p*q)]
  }

  B0=solve(t(G)%*%XyXy%*%G)%*%t(G)%*%XyY

  la=solve(t(G)%*%XyXy%*%G)

  if(ay==1){
    sig=Sest3(XY,XX,YYcross,B0,n,p,q)
  }else{
    sig=Sestb(XY,XX,YYcross,BM,n,p,q)
  }

  corB0=la%*%(t(G)%*%XyXy%*%G)%*%t(la)*sig

  V0=matrix(0,nrow=p,ncol=p*q+p*(p-1)-length(suby)*(p-1))
  V0[1:p,1:p]=diag(p)

  if(ay==0){
    cv=1:(p*q)
  }else{
    cv=1:ncol(V0)
  }

  v1=as.matrix(V0[-k,cv])
  if(min(dim(v1))==1){
    v1=t(v1)
  }

  bb3b=B0
  cc3b=corB0

  if(method=="wald"){
    if(ay==1){
      A=Sest2(XY,XX,YYcross,B0,n,suby,p,q)   #get Sigma     RIGHT when XX=XXtrue
    }
    else{
      A=Sest(XY,XX,YYcross,BM,n,p,q)
      #A=A*(2*n-p*(q+p-1))/(2*n-1)
      #A=diag(2)*Sestb(XY,XX,YYcross,BM,n)
    }

    if(ay==1){
      XYW=rbind(cbind(XX,XY),cbind(t(XY),YYcross))
    }else{
      #XYW=kronecker(XX,diag(p))
      XYW=XX
      G=G[1:(p*q),]
    }

    #XXni=t(G)%*%kronecker(solve(XYW),diag(p))%*%G
    XXni=solve(t(G)%*%kronecker(XYW,diag(p))%*%G)
    AA2=kronecker(XYW,A)
    XCX=t(G)%*%AA2%*%G
    cc3b=XXni%*%XCX%*%XXni
  }


  w1=t(v1%*%bb3b)%*%solve(v1%*%cc3b%*%t(v1))%*%v1%*%bb3b

  #w1=t(v1%*%bb3b)%*%solve(v1%*%kronecker(diag(2),cc3)%*%t(v1))%*%v1%*%bb3b

  return(w1)
}






Sest=function(XY,XX,YY,B,n,p,q){       #don't adjust for Y. Sig (not diagonal)
  Sig=YY+B%*%XX%*%t(B)-B%*%XY-t(B%*%XY)
  Sig=Sig/(n-p*q)
  return(Sig)
}

Sestb=function(XY,XX,YY,B,n,p,q){    #don't adjust for Y. sigma (Sig is diagonal)
  Sig=YY+B%*%XX%*%t(B)-B%*%XY-t(B%*%XY)
  Sig=sum(diag(Sig))/(2*n-p*q)
  return(Sig)
}

Sest2=function(XY,XX,YYcross,B0,n,suby,p,q){    #conditional, Sig (not diagonal)
  B0d=as.vector(B0)
  B00=B0d
  if(length(suby)>0){
    for(i in 1:length(suby)){
      B00=append(B00,rep(0,p-1),after=suby[i]+p*q-1)
    }
  }

  B4=B00[1:(p*q)]
  B01=B00[-c(1:(p*q))]

  for(i in 1:(p-1)){
    B4=c(B4,0,B01[((i-1)*p+1):(i*p)])
  }

  B4=c(B4,0)
  B4=matrix(B4,nrow=p)
  XX4=rbind(cbind(XX,XY),cbind(t(XY),YYcross))
  XY4=rbind(XY,YYcross)
  Sig=YYcross+B4%*%XX4%*%t(B4)-B4%*%XY4-t(B4%*%XY4)
  Sig=Sig/(n-p*(q+p-1))
  return(Sig)
}

Sest3=function(XY,XX,YYcross,B0,n,p,q){    #conditional, sigma (Sig is diagonal)
  B00=as.vector(B0)
  B4=B00[1:(p*q)]
  B01=B00[-c(1:(p*q))]
  for(i in 1:(p-1)){
    B4=c(B4,0,B01[((i-1)*p+1):(i*p)])
  }
  B4=c(B4,0)
  B4=matrix(B4,nrow=p)
  XX4=rbind(cbind(XX,XY),cbind(t(XY),YYcross))
  XY4=rbind(XY,YYcross)
  Sig=YYcross+B4%*%XX4%*%t(B4)-B4%*%XY4-t(B4%*%XY4)
  sig=sum(diag(Sig))/(2*n-p*(q+p-1))
  return(sig)
}

vecX=function(X0,p){
  q=ncol(X0)
  n=nrow(X0)
  VV=matrix(0,nrow=n*p,ncol=p*q)
  for(i in 1:q){
    for(j in 1:p){
      VV[c(1:n+n*(j-1)),p*(i-1)+j]=X0[,i]
    }
  }
  return(VV)
}


Sest22=function(XY,XX,YYcross,B0,n,p,q){    #conditional, for lrt
  B00=as.vector(B0)
  B4=B00[1:(p*q)]
  B01=B00[-c(1:(p*q))]
  for(i in 1:(p-1)){
    B4=c(B4,0,B01[((i-1)*p+1):(i*p)])
  }
  B4=c(B4,0)
  B4=matrix(B4,nrow=p)
  XX4=rbind(cbind(XX,XY),cbind(t(XY),YYcross))
  XY4=rbind(XY,YYcross)
  Sig=YYcross+B4%*%XX4%*%t(B4)-B4%*%XY4-t(B4%*%XY4)
  Sig=Sig/(n-p*(q+p-1))
  return(Sig)
}
